module.exports = {
  purge: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    fontFamily: {
      poppins: ["Poppins", "sans-serif"],
    },
    extend: {
      backgroundImage: {
        login: "url('./assets/login-background.jpg')",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
