import { createSlice } from "@reduxjs/toolkit";

const theaterSlice = createSlice({
  name: "theater",
  initialState: [],
  reducers: {
    FETCHED_THEATERS: (state, action) => {
      return action.payload;
    },
    ADD_THEATER: (state, action) => {
      return [...state, action.payload];
    },
    UPDATE_THEATER: (state, action) => {
      const { id, data } = action.payload;

      return state.map((theater) =>
        theater.secret === id ? { ...theater, data } : theater
      );
    },
    CHANGE_STATUS: (state, action) => {
      const { id, status } = action.payload;

      return state.map((theater) =>
        theater.secret === id ? { ...theater, status } : theater
      );
    },
  },
});

export const { FETCHED_THEATERS, ADD_THEATER, CHANGE_STATUS } =
  theaterSlice.actions;

export default theaterSlice.reducer;
