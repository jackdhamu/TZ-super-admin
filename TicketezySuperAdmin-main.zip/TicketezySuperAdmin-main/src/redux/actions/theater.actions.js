import axios from "../../axios";
import {
  ADD_THEATER,
  FETCHED_THEATERS,
  CHANGE_STATUS,
} from "../reducers/theater.reducer";

export const getTheaters = (handleLoading, handleError) => async (dispatch) => {
  try {
    handleLoading(true);
    const result = await axios.get("/theatres");
    dispatch(FETCHED_THEATERS(result.data));
  } catch (err) {
    handleError("Something went wrong");
  } finally {
    handleLoading(false);
  }
};

export const createTheater =
  (theaterData, handleLoading, handleError, clearField, onClose) =>
  async (dispatch) => {
    try {
      handleLoading(true);
      const result = await axios.post("/theatres", theaterData);
      dispatch(ADD_THEATER({ ...theaterData, ...result?.data?.message }));
      clearField();
      onClose();
    } catch (err) {
      handleError(err?.response?.data?.errors);
    } finally {
      handleLoading(false);
    }
  };

export const updateTheater =
  (theaterData, id, handleLoading, handleError) => async (dispatch) => {
    try {
      handleLoading(true);
      const result = await axios.patch(`/theatres/${id}/update`, {
        theatre: theaterData,
      });
      console.log(result);
    } catch (err) {
      handleError(err?.response?.data?.errors);
      console.log(err);
    } finally {
      handleLoading(false);
    }
  };

export const changeStatus = (id, status) => async (dispatch) => {
  try {
    dispatch(CHANGE_STATUS({ id, status }));
    await axios.patch(`/theatres/${id}/change-status`, {
      status,
    });
  } catch (err) {
    console.log(err);
  }
};

export const deleteTheater = (id) => async (dispatch) => {
  try {
    const result = await axios.delete(`/theatres/${id}`);
    console.log(result);
  } catch (err) {
    console.log(err);
  }
};
