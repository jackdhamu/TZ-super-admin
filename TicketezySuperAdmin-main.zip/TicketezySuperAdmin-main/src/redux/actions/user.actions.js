import axios from "../../axios";
import { FETCHED_USER } from "../reducers/user.reducer";

export const login =
  (credentials, handleLoading, handleError) => async (dispatch) => {
    try {
      handleLoading(true);
      const result = await axios.post("/super_admins/login", credentials);
      dispatch(FETCHED_USER(result.data.message.cookies));
    } catch (err) {
      handleError("Invalid username/password");
    } finally {
      handleLoading(false);
    }
  };