import { BrowserRouter, Route } from "react-router-dom";
import { useSelector } from "react-redux";

import PrivateRoute from "./components/PrivateRoute";
import PublicRoute from "./components/PublicRoute";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import ScreenLayout from "./pages/ScreenLayout";

function App() {
  const state = useSelector((state) => state);

  console.log(state);

  return (
    <BrowserRouter>
      <PrivateRoute path="/" component={Dashboard} redirectTo="/login" />
      <PublicRoute path="/login" exact component={Login} redirectTo="/" />
      <Route path="/screen-layout" component={ScreenLayout} />
    </BrowserRouter>
  );
}

export default App;
