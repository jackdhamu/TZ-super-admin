import React from "react";

const Select = ({ onChange, value }) => {
  return (
    <div className="flex flex-col mb-1">
      <label className="text-sm mb-1">
        <span className="text-red-500 mr-1">*</span>Theater Type
      </label>
      <select
        name="theatre_type"
        onChange={onChange}
        value={value}
        className="bg-transparent border-2 border-gray-400 rounded p-1 outline-none text-gray-400"
      >
        <option value="ac">AC</option>
        <option value="non_ac">NON-AC</option>
      </select>
    </div>
  );
};

export default Select;
