import React from "react";
import { useDispatch } from "react-redux";
import { changeStatus } from "../redux/actions/theater.actions";

const Switch = ({ status, id }) => {
  const isActive = status === "active";

  const dispatch = useDispatch();

  const handleChange = () => {
    const currentStatus = !isActive ? "active" : "inactive";
    dispatch(changeStatus(id, currentStatus));
  };

  return (
    <label className="flex items-center cursor-pointer">
      <div className="relative">
        <input
          type="checkbox"
          className="sr-only"
          checked={isActive}
          onChange={handleChange}
        />
        <div
          className={"block bg-gray-200 w-24 h-8 rounded-full toggler"}
        ></div>
        <div
          className={
            "dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition"
          }
        ></div>
      </div>
    </label>
  );
};

export default Switch;
