import React from "react";

import Header from "./Header";

const Drawer = ({ children, visible = false, title, onClose }) => {
  return (
    <>
      <div
        className={`z-10 ${visible && "w-full h-full"} fixed top-0 left-0`}
        onClick={onClose}
      ></div>
      <div
        className={`bg-gray-100 w-96 h-screen fixed z-50 top-0 right-0 shadow-md transition-all transform   ${
          visible ? "translate-x-0" : "translate-x-96"
        }`}
      >
        <Header
          title={title}
          className="text-center mb-1 shadow-md p-2 font-normal"
        />
        {children}
      </div>
    </>
  );
};

export default Drawer;
