import React from "react";

const Header = ({ title, className }) => {
  const style = className ? className : "";

  return <h1 className={`text-xl font-bold capitalize ${style}`}>{title}</h1>;
};

export default Header;
