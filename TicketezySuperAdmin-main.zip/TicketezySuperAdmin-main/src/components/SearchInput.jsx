import React from "react";
import { FaSearch } from "react-icons/fa";

import Input from "./Input";

const SearchInput = ({ onClick, className, buttonStyle }) => {
  const style = className ? className : "";

  return (
    <>
      <Input
        type="text"
        placeholder="Search by Theater ID / Theater Name / Location"
        className={`border-gray text-black placeholder-gray-500 w-full min-w-96 rounded-tr-none rounded-br-none p-4 h-14 rounded-lg ${style}`}
      />
      <button
        type="button"
        className={`border-2 border-l-0 rounded-tr-lg rounded-br-lg p-3 pb-2 h-14 ${
          buttonStyle ? buttonStyle : ""
        }`}
        onClick={onClick}
      >
        <FaSearch size={24} />
      </button>
    </>
  );
};

export default SearchInput;
