import React from "react";

import FormField from "./FormField";

const SetAccount = ({ onClose }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <form className="px-4 py-1" onSubmit={handleSubmit}>
      <div className="h-85 overflow-y-auto px-4 py-1">
        <FormField
          type="text"
          label="Account Holder Name"
          placeholder="Enter Account Holder Name"
          required
        />
        <FormField
          type="text"
          label="Account Number"
          placeholder="Enter Account Number"
          required
        />
        <FormField
          type="text"
          label="Bank Name"
          placeholder="Enter Bank Name"
          required
        />
        <FormField
          type="text"
          label="IFSC Code"
          placeholder="Enter IFSC Code"
          required
        />
        <FormField
          type="text"
          label="Branch Name"
          placeholder="Enter Branch Name"
          required
        />
        <FormField
          type="text"
          label="PAN Number"
          placeholder="Enter PAN Number"
          required
        />
        <FormField
          type="text"
          label="GST Number"
          placeholder="Enter GST Number"
          required
        />
        <FormField
          type="text"
          label="Aadhar Number"
          placeholder="Enter Aadhar Number"
          required
        />
        <FormField
          type="file"
          label="Cancel Cheque"
          placeholder="Upload Cheque"
          required
        />
        <FormField
          type="file"
          label="C Form"
          placeholder="Upload C Form"
          required
        />
      </div>
      <div className="absolute bottom-0 right-0 p-2 px-4 bg-gray-200 w-full text-right">
        <button
          type="button"
          className="p-1 bg-white border-gray-500 border-2 rounded mr-4"
          onClick={onClose}
        >
          Cancel
        </button>
        <button
          type="submit"
          className="bg-blue-500 text-white p-1 px-2 rounded"
        >
          Create
        </button>
      </div>
    </form>
  );
};

export default SetAccount;
