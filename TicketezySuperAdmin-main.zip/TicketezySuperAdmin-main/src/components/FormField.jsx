import React from "react";

import Input from "./Input";

const FormField = ({
  type,
  placeholder,
  value,
  onChange,
  label,
  required,
  name,
  error,
}) => {
  return (
    <div className="mb-1">
      <label className="text-sm">
        {required && <span className="text-red-500 mr-1 text-black">*</span>}
        {label}
      </label>
      <Input
        type={type}
        name={name}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={"p-1 px-2 text-sm rounded-md mt-1 border-gray-400"}
        required
        error={error}
      />
    </div>
  );
};

export default FormField;
