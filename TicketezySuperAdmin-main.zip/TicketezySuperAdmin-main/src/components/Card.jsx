import React from "react";

const Card = ({ title, onClick }) => {
  return (
    <div
      className="flex items-center justify-center bg-white shadow-md w-52 h-52 rounded-lg m-6"
      onClick={onClick}
    >
      <p className="font-bold">{title}</p>
    </div>
  );
};

export default Card;
