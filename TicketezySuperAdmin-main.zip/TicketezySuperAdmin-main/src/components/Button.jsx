import React from "react";

const Button = ({ type, children, className, onClick, loading = false }) => {
  return (
    <button
      className={`bg-blue-500 text-white p-2 rounded-md ${
        className ? className : ""
      }`}
      type={type}
      onClick={onClick}
      disabled={loading}
    >
      {loading ? (
        <div className="flex items-center justify-center">
          <div class="bg-white bg-opacity-60 p-1  w-1 h-1 mr-2 rounded-full animate-bounce first-circle"></div>
          <div class="bg-white bg-opacity-40 p-1 w-1 h-1 mr-2 rounded-full animate-bounce middle-circle"></div>
          <div class="bg-white bg-opacity-80 p-1  w-1 h-1 rounded-full animate-bounce last-circle"></div>
        </div>
      ) : (
        <p>{children}</p>
      )}
    </button>
  );
};

export default Button;
