import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { createTheater } from "../redux/actions/theater.actions";

import FormField from "./FormField";
import Select from "./Select";

const initialState = {
  name: "",
  owner: "",
  mobile: "",
  address: "",
  place: "",
  location: "",
  since: "",
  theatre_type: "",
  pan_number: "",
  gst_number: "",
  aadhar_number: "",
};

const CreateTheater = ({ onClose }) => {
  const [theater, setTheater] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState("");

  const dispatch = useDispatch();

  const handleError = (message) => setErrors(message);
  const handleLoading = (value) => setLoading(value);

  const clearField = () => setTheater(initialState);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTheater({ ...theater, [name]: value });
  };

  const handleClose = () => {
    setErrors("");
    onClose();
    clearField();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(
      createTheater(theater, handleLoading, handleError, clearField, onClose)
    );
  };

  return (
    <form className=" w-full h-full" onSubmit={handleSubmit}>
      <div className="h-85 overflow-y-auto px-4 py-1">
        <FormField
          type="text"
          label="Theater Name"
          placeholder="Enter Theater Name"
          required
          name="name"
          value={theater.name}
          onChange={handleChange}
          error={errors?.name}
        />
        <FormField
          type="text"
          label="Owner Name"
          placeholder="Enter Owner Name"
          required
          name="owner"
          value={theater.owner}
          onChange={handleChange}
          error={errors?.owner}
        />
        <FormField
          type="text"
          label="Mobile Number"
          placeholder="Enter Mobile Number"
          required
          name="mobile"
          value={theater.mobile}
          onChange={handleChange}
          error={errors?.mobile}
        />
        <FormField
          type="text"
          label="Theater Address"
          placeholder="Enter Theater Address"
          required
          name="address"
          value={theater.address}
          onChange={handleChange}
          error={errors?.address}
        />
        <FormField
          type="text"
          label="Theater Place"
          placeholder="Enter Theater Place"
          required
          name="place"
          value={theater.place}
          onChange={handleChange}
          error={errors?.place}
        />
        <FormField
          type="text"
          label="Location"
          placeholder="Enter Location (Map)"
          required
          name="location"
          value={theater.location}
          onChange={handleChange}
          error={errors?.location}
        />
        <FormField
          type="text"
          label="Theater Started Year"
          placeholder="Enter Theater Started Year"
          required
          name="since"
          value={theater.since}
          onChange={handleChange}
          error={errors?.since}
        />
        <Select onChange={handleChange} value={theater.theatre_type} />
        <FormField
          type="text"
          label="PAN Number"
          placeholder="Enter PAN Number"
          required
          name="pan_number"
          value={theater.pan_number}
          onChange={handleChange}
          error={errors?.pan_number}
        />
        <FormField
          type="text"
          label="GST Number"
          placeholder="Enter GST Number"
          required
          name="gst_number"
          value={theater.gst_number}
          onChange={handleChange}
          error={errors?.gst_number}
        />
        <FormField
          type="text"
          label="Aadhaar Number"
          placeholder="Enter Aadhaar Number"
          required
          name="aadhar_number"
          value={theater.aadhar_number}
          onChange={handleChange}
          error={errors?.aadhar_number}
        />
      </div>
      <div className="p-2 px-4 fixed bottom-0 left-0 w-full text-right bg-gray-200">
        <button
          type="button"
          className="border-gray-500 p-1 px-2 border-2 mr-3 rounded bg-white"
          onClick={handleClose}
        >
          Cancel
        </button>
        <button
          type="submit"
          className="bg-blue-500 text-white p-1 px-2 rounded"
          disabled={loading}
        >
          {loading ? "loading..." : "Create"}
        </button>
      </div>
    </form>
  );
};

export default CreateTheater;
