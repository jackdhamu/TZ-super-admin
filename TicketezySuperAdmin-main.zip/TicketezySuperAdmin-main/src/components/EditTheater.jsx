import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { updateTheater } from "../redux/actions/theater.actions";

import FormField from "./FormField";
import Select from "./Select";

const initialState = {
  name: "",
  owner: "",
  mobile: "",
  address: "",
  place: "",
  location: "",
  since: "",
  theatre_type: "ac",
  pan_number: "",
  gst_number: "",
  aadhar_number: "",
};

const EditTheater = ({ onClose, selectedId }) => {
  const [theater, setTheater] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLoading = (value) => setLoading(value);
  const handleError = (message) => setError(message);

  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTheater({ ...theater, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(updateTheater(theater, selectedId, handleLoading, handleError));
  };

  return (
    <form className="w-full h-full" onSubmit={handleSubmit}>
      {error && (
        <p className="w-full text-center text-sm text-red-500">{error}</p>
      )}
      <div className="h-85 overflow-y-auto px-4 py-1">
        <FormField
          type="text"
          label="Theater Name"
          placeholder="Enter Theater Name"
          name="name"
          value={theater.name}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Owner Name"
          placeholder="Enter Owner Name"
          name="owner"
          value={theater.owner}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Mobile Number"
          placeholder="Enter Mobile Number"
          name="mobile"
          value={theater.mobile}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Theater Address"
          placeholder="Enter Theater Address"
          name="address"
          value={theater.address}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Theater Place"
          placeholder="Enter Theater Place"
          name="place"
          value={theater.place}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Location"
          placeholder="Enter Location (Map)"
          name="location"
          value={theater.location}
          onChange={handleChange}
          required
        />
        <FormField
          type="text"
          label="Theater Started Year"
          placeholder="Enter Theater Started Year"
          name="since"
          value={theater.since}
          onChange={handleChange}
          required
        />
        <Select onChange={handleChange} value={theater.theatre_type} />
        <FormField
          type="text"
          label="PAN Number"
          placeholder="Enter PAN Number"
          required
          name="pan_number"
          value={theater.pan_number}
          onChange={handleChange}
        />
        <FormField
          type="text"
          label="GST Number"
          placeholder="Enter GST Number"
          required
          name="gst_number"
          value={theater.gst_number}
          onChange={handleChange}
        />
        <FormField
          type="text"
          label="Aadhaar Number"
          placeholder="Enter Aadhaar Number"
          required
          name="aadhar_number"
          value={theater.aadhar_number}
          onChange={handleChange}
        />
      </div>
      <div className="absolute bottom-0 right-0 p-2 px-4 bg-gray-200 w-full text-right">
        <button
          type="button"
          className="p-1 bg-white border-gray-500 border-2 rounded mr-4"
          onClick={onClose}
        >
          Cancel
        </button>
        <button
          type="submit"
          className="bg-blue-500 text-white p-1 px-2 rounded"
        >
          Create
        </button>
      </div>
    </form>
  );
};

export default EditTheater;
