import React from "react";
import { useSelector } from "react-redux";

const TheaterInfo = ({ selectedId, visible, onClose }) => {
  const theaters = useSelector((state) => state.theater);

  const theater = theaters.filter(
    (theater) => theater.secret === selectedId
  )[0];

  console.log(theater);

  if (!visible) return null;

  return (
    <>
      <div
        className={`z-10 ${visible && "w-full h-full"} fixed top-0 left-0`}
        onClick={onClose}
      ></div>
      <div className="w-96 p-4 z-40 fixed right-20 rounded-md top-1/4 bg-white shadow">
        <p className="font-bold text-xl mb-4">{theater.name}</p>
        <div className="flex mb-2 items-center">
          <label className="mr-2 flex-3 ">Theater Type</label>
          <p className="w-3 h-2 rounded-xl bg-blue-500 mr-2"></p>
          <p className="flex-1 text-sm uppercase">
            {theater.theatre_type || "Not updated"}
          </p>
        </div>
        <div className="flex mb-2 items-center">
          <label className="mr-2 flex-3  ">Owner Name</label>
          <p className="w-3 h-2 rounded-xl bg-blue-500 mr-2"></p>
          <p className="flex-1 text-sm">{theater.owner || "Not updated"}</p>
        </div>
        <div className="flex mb-2 items-center">
          <label className="mr-2 flex-3 ">Phone Number</label>
          <p className="w-3 h-2 rounded-xl bg-blue-500 mr-2"></p>
          <p className="flex-1 text-sm">
            +91-{theater.mobile || "Not updated"}
          </p>
        </div>
        <div className="flex mb-2 items-center">
          <label className="mr-2 flex-3 ">Owner Address</label>
          <p className="w-3 h-2 rounded-xl bg-blue-500 mr-2"></p>
          <p className="flex-1 text-sm">{theater.address || "Not updated"}</p>
        </div>
        <div className="flex mb-2 items-center">
          <label className="mr-2 flex-3 ">Theater Started Since</label>
          <p className="w-3 h-2 rounded-xl bg-blue-500 mr-2"></p>
          <p className="flex-1 text-sm">{theater?.since || "Not updated"}</p>
        </div>
      </div>
    </>
  );
};

export default TheaterInfo;
