import React from "react";
import { useSelector } from "react-redux";
import { Redirect, Route } from "react-router";

import { selectUser } from "../redux/reducers/user.reducer";

const PrivateRoute = ({ path, component, exact = false, redirectTo }) => {
  const user = useSelector(selectUser);

  if (!user) return <Redirect to={redirectTo} />;

  return <Route path={path} exact={exact} component={component} />;
};

export default PrivateRoute;
