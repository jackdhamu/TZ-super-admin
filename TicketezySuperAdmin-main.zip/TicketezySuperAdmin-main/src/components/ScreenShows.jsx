import React from "react";
import { FaCalendar } from "react-icons/fa";
import { Link } from "react-router-dom";

const ScreenShows = ({ visible, onClose }) => {
  return (
    <>
      <div
        className={`z-10 ${visible && "w-full h-full"} fixed top-0 left-0`}
        onClick={onClose}
      ></div>
      <div
        className={`w-3/4 h-2/3 shadow-lg z-40  bg-white absolute left-40 top-40 rounded-lg ${
          visible ? "" : "hidden"
        } `}
      >
        <div className="p-5 flex bg-gray-100">
          <img
            src="https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fspecials-images.forbesimg.com%2Fimageserve%2F5de68156c283810006a3879a%2FDaniel-Craig-as-James-Bond-in--No-Time-to-Die-%2F960x0.jpg%3Ffit%3Dscale"
            alt=""
            className="w-96 h-64 bg-gray-400 rounded-lg overflow-hidden mr-10 object-cover"
          />
          <div>
            <h3 className="text-black font-bold text-2xl capitalize mb-5">
              No Time To Die
            </h3>
            <p className="text-sm mb-5">
              James Bond has left active service. His peace is short-lived when
              Felix Leiter, an old friend from the CIA, turns up asking for
              help, leading Bond onto the trail of a mysterious villain armed
              with dangerous new technology.
            </p>
            <p className="text-black">Director : Cary Joji Fukunaga</p>
            <p className="text-black">
              Stars: Daniel Craig , Ana de Armas ,Rami Malek
            </p>
          </div>
        </div>
        <div className="p-5 overflow-visible">
          <div className="flex items-center justify-start">
            <h1 className="text-black font-bold mr-10">Today Shows</h1>
            <div className="flex flex-wrap">
              <Link
                to="/screen-layout"
                className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg"
              >
                11.45AM
              </Link>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                02.30PM
              </p>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                6:45PM
              </p>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                10:30PM
              </p>
            </div>
          </div>
          <div className="flex items-center justify-start ">
            <h1 className="text-black font-bold mr-10">Tomorrow Shows</h1>
            <div className="flex flex-wrap">
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                11.45AM
              </p>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                02.30PM
              </p>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                6:45PM
              </p>
              <p className="bg-gray-200 m-2 shadow-sm p-2 px-3 rounded-lg">
                10:30PM
              </p>
            </div>
          </div>
          <button type="button" className="flex items-center mt-3 text-black ">
            <h3 className="font-bold mr-3">Past Shows</h3>
            <FaCalendar />
          </button>
        </div>
      </div>
    </>
  );
};

export default ScreenShows;
