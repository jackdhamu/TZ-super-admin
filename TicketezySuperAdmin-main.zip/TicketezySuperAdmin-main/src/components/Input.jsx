import React, { useState } from "react";
import { FaEye, FaEyeSlash, FaFile } from "react-icons/fa";

const Input = ({
  type,
  placeholder,
  name,
  value,
  onChange,
  className,
  required = false,
  autoComplete = false,
  error,
}) => {
  const [inputType, setInputType] = useState(type);

  const condition = type === "password";

  const _renderIcon = () => {
    if (condition) {
      return (
        <p className="absolute top-4 right-4">
          {inputType === "text" ? (
            <FaEye
              size={24}
              color="#fff"
              onClick={() => setInputType("password")}
            />
          ) : (
            <FaEyeSlash
              size={24}
              color="#fff"
              onClick={() => setInputType("text")}
            />
          )}
        </p>
      );
    } else if (type === "file") {
      return (
        <p className="absolute top-3 right-2">
          <FaFile />
        </p>
      );
    }
  };

  return (
    <div className="relative w-full">
      <input
        className={`p-1 w-full bg-transparent border-2 outline-none ${
          condition && "pr-10"
        } ${className ? className : ""} `}
        name={name}
        onChange={onChange}
        placeholder={placeholder}
        type={inputType}
        value={value}
        required={required}
        autoComplete={autoComplete}
      />
      <p className="text-xs text-red-500 mt-1">{error}</p>
      {_renderIcon()}
    </div>
  );
};

export default Input;
