import React from "react";
import { MdDelete } from "react-icons/md";

const DeleteModal = ({ visible, no, yes }) => {
  return (
    <>
      <div
        className={`z-10 ${visible && "w-full h-full"} fixed top-0 left-0`}
        onClick={no}
      ></div>
      <div
        className={`fixed bottom-40 z-40 right-10 w-80 bg-white shadow-lg p-5 rounded-lg transform transition-all ${
          visible ? "translate-x-0" : "translate-x-96"
        }`}
      >
        <p className="text-center">
          <MdDelete size={32} color="black" />
        </p>
        <p className="text-black text-xs mt-2">
          Are You Sure You Want To Delete this ? If You choose Yes The Data Will
          permanently Deleted You Can't Use or restore it anymore
        </p>
        <div className="text-black flex items-center justify-around mt-4">
          <button
            type="button"
            className="hover:underline px-2 py-1"
            onClick={yes}
          >
            Yes
          </button>
          <button
            type="button"
            className="hover:underline px-2 py-1"
            onClick={no}
          >
            No
          </button>
        </div>
      </div>
    </>
  );
};

export default DeleteModal;
