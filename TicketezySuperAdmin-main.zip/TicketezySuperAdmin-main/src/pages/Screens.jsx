import React, { useState } from "react";

import Card from "../components/Card";
import ScreenShows from "../components/ScreenShows";
import SearchInput from "../components/SearchInput";

const screens = [1, 2, 3, 4, 5, 6, 7, 8];

const Screens = () => {
  const [screenShowsVisible, setScreenShowsVisible] = useState(false);

  console.log(screenShowsVisible);

  const handleScreenShowsVisible = () =>
    setScreenShowsVisible(!screenShowsVisible);

  return (
    <div className="w-full px-10 pt-10 bg-blue-500 h-full relative overflow-auto">
      <h1 className="text-3xl font-bold text-center text-white mb-10">
        Ticketezy Main Admin Dashboard
      </h1>
      <div className="flex justify-between items-center">
        <div className="flex-1 mr-80 flex">
          <SearchInput className="bg-white" buttonStyle="bg-white" />
        </div>
        <select
          value=""
          className="flex-3 p-4 outline-none rounded-lg font-bold"
        >
          <option value="">Sort By</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
        </select>
      </div>
      <div className="mt-10 flex flex-wrap justify-between">
        {screens.map((number) => (
          <Card title={`Screen ${number}`} onClick={handleScreenShowsVisible} />
        ))}
      </div>
      <ScreenShows
        onClose={handleScreenShowsVisible}
        visible={screenShowsVisible}
      />
    </div>
  );
};

export default Screens;
