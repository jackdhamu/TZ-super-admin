import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { FaEye, FaUniversity } from "react-icons/fa";
import { FiEdit2 } from "react-icons/fi";
import { MdDelete } from "react-icons/md";

import Button from "../components/Button";
import CreateTheater from "../components/CreateTheater";
import Drawer from "../components/Drawer";
import EditTheater from "../components/EditTheater";
import Header from "../components/Header";
import SearchInput from "../components/SearchInput";
import SetAccount from "../components/SetAccount";
import Switch from "../components/Switch";
import DeleteModal from "../components/DeleteModal";
import TheaterInfo from "../components/TheaterInfo";
import { deleteTheater, getTheaters } from "../redux/actions/theater.actions";

const buttons = ["Filter", "Theater ID", "Theater Name", "Theater Location"];
const tableHeadings = [
  "Theater ID",
  "Name",
  "Type",
  "Address",
  "Location (Map)",
  "Status",
  "Account",
  "Actions",
];

const initialState = {
  createTheater: false,
  setAccount: false,
  editTheater: false,
};

const TheaterDetails = () => {
  const [drawersVisible, setDrawersVisible] = useState(initialState);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [isDelete, setIsDelete] = useState(false);

  const [selectedDeleteId, setSelectedDeleteId] = useState("");
  const [selectedUpdateId, setSelectedUpdateId] = useState("");
  const [selectedShowId, setSelectedShowId] = useState("");

  const [visibleDetails, setVisibleDetails] = useState(false);

  const dispatch = useDispatch();
  const theaters = useSelector((state) => state.theater);

  const handleDrawerChange = (name) => {
    setDrawersVisible({ ...drawersVisible, [name]: !drawersVisible[name] });
  };

  const handleVisibleDetails = () => setVisibleDetails(!visibleDetails);

  const handleError = (message) => setError(message);
  const handleLoading = (value) => setLoading(value);

  const handleUpdateOpen = (id) => {
    setSelectedUpdateId(id);
    handleDrawerChange("editTheater");
  };

  const handleUpdateClose = () => {
    setSelectedUpdateId("");
    handleDrawerChange("editTheater");
  };

  const handleShowDetailsOpen = (id) => {
    setSelectedShowId(id);
    handleVisibleDetails();
  };

  const handleShowDetailsClose = () => {
    setSelectedShowId("");
    handleVisibleDetails();
  };

  const handleDeleteOpen = (id) => {
    setSelectedDeleteId(id);
    handleDeleteModalVisible();
  };

  const handleDeleteClose = () => {
    setSelectedDeleteId("");
    handleDeleteModalVisible();
  };

  const handleDeleteModalVisible = () => setIsDelete(!isDelete);

  const handleDeleteTheater = () => {
    dispatch(deleteTheater(selectedDeleteId));
    handleDeleteModalVisible();
  };

  useEffect(() => {
    dispatch(getTheaters(handleLoading, handleError));
  }, []);

  if (loading) {
    return (
      <div className="flex w-full h-full items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="p-10 overflow-auto overflow-x-hidden h-full">
      {error && (
        <p className="bg-gray-100 p-2 text-center text-red-500 absolute top-0 left-1/2 transform -translate-x-1/2 m-2 border-red-600 border-l-2 text-sm rounded font-bold">
          {error}
        </p>
      )}
      <Header title="theater details" className="mb-7" />
      <div className="flex items-center justify-between mb-5">
        <div className="flex-1 mr-80 flex">
          <SearchInput />
        </div>
        <Button
          type="button"
          className="rounded-xl flex-3 px-10 p-3"
          onClick={() => handleDrawerChange("createTheater")}
        >
          Create Theater
        </Button>
      </div>
      <>
        {buttons.map((name) => (
          <Button type="button" className="mr-3 rounded-xl p-3" key={name}>
            {name}
          </Button>
        ))}
      </>
      {theaters.length === 0 ? (
        <p className="mt-10 text-center font-bold">No Theaters Available</p>
      ) : (
        <table className="w-full mt-5 p-5 table-auto ">
          <thead className="p-5 m-5 border-2 text-center">
            <tr className="p-5 m-5 border-2 text-center font-normal">
              {tableHeadings.map((content) => (
                <th key={content} className="p-4">
                  {content}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {theaters?.map((data) => (
              <tr key={data.secret} className="text-center shadow-md">
                <td className="px-6 py-4">{data.support_id}</td>
                <td className="px-6 py-4">{data.name}</td>
                <td className="px-6 py-4 uppercase">
                  {data.theatre_type?.replace("_", "-")}
                </td>
                <td className="px-6 py-4">{data.address}</td>
                <td className="px-6 py-4 underline text-blue-800">
                  <Link
                    to={{
                      pathname: data.location,
                    }}
                    target="_blank"
                  >
                    {data.location}
                  </Link>
                </td>
                <td className="px-6 py-4">
                  <p>{data.status}</p>
                  <Switch status={data.status} id={data.secret} />
                </td>
                <td>
                  <Button
                    type="button"
                    className="p-3 text-xs"
                    onClick={() => handleDrawerChange("setAccount")}
                  >
                    Set Account
                  </Button>
                </td>
                <td className="p-6">
                  <div className="bg-blue-500 text-white flex justify-between p-3 rounded-lg">
                    <Link to="/screens" className="mr-2">
                      <FaUniversity />
                    </Link>
                    <p
                      onClick={() => handleUpdateOpen(data.secret)}
                      className="cursor-pointer mr-2"
                    >
                      <FiEdit2 />
                    </p>
                    <p
                      className="mr-2 cursor-pointer"
                      onClick={() => handleShowDetailsOpen(data.secret)}
                    >
                      <FaEye />
                    </p>
                    <p className="cursor-pointer">
                      <MdDelete onClick={() => handleDeleteOpen(data.secret)} />
                    </p>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <Drawer
        visible={drawersVisible.createTheater}
        title="Create Theater"
        onClose={() => handleDrawerChange("createTheater")}
      >
        <CreateTheater onClose={() => handleDrawerChange("createTheater")} />
      </Drawer>
      <Drawer
        visible={drawersVisible.setAccount}
        title="Set Account"
        onClose={() => handleDrawerChange("setAccount")}
      >
        <SetAccount onClose={() => handleDrawerChange("setAccount")} />
      </Drawer>
      <Drawer
        visible={drawersVisible.editTheater}
        title="Edit Theater"
        onClose={handleUpdateClose}
      >
        <EditTheater
          onClose={handleUpdateClose}
          selectedId={selectedUpdateId}
        />
      </Drawer>
      <DeleteModal
        visible={isDelete}
        yes={handleDeleteTheater}
        no={handleDeleteClose}
      />
      <TheaterInfo
        visible={visibleDetails}
        selectedId={selectedShowId}
        onClose={handleShowDetailsClose}
      />
    </div>
  );
};

export default TheaterDetails;
