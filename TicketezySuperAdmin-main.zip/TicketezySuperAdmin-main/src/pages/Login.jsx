import React, { useState } from "react";
import { useDispatch } from "react-redux";

import Button from "../components/Button";
import Input from "../components/Input";
import { login } from "../redux/actions/user.actions";

const initialState = {
  user_name: "!@#TICKETEZY!@#",
  password: "Ticketezy@123",
};

const Login = () => {
  const [credentials, setCredentials] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const dispatch = useDispatch();

  const handleLoading = (value) => setLoading(value);
  const handleError = (message) => setError(message);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials({ ...credentials, [name]: value });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    handleError("");
    dispatch(login(credentials, handleLoading, handleError));
  };

  return (
    <div className="w-screen h-screen text-red bg-login object-cover bg-cover flex flex-row items-center justify-center">
      <div className="bg-gray-100 bg-opacity-10 w-1/3 min-w-96 max-w-7xl h-auto flex flex-col p-10 py-20 rounded-2xl">
        <h3 className="text-6xl font-bold text-white text-center">Ticketezy</h3>
        <h5 className="text-lg mt-1 text-white text-center">
          Main Admin Dashboard
        </h5>
        <form className="mt-10 flex flex-col" onSubmit={handleSubmit}>
          <Input
            className="mb-7 text-xl text-white placeholder-white p-3 rounded-lg"
            onChange={handleChange}
            name="user_name"
            placeholder="Login ID"
            type="text"
            value={credentials.user_name}
          />
          <Input
            className="mb-7 text-xl text-white placeholder-white p-3 rounded-lg"
            name="password"
            onChange={handleChange}
            placeholder="Password"
            type="password"
            value={credentials.password}
            autoComplete
          />
          <div className="text-center">
            <Button
              className="border-2 w-32 h-12 font-bold text-xl"
              type="submit"
              loading={loading}
            >
              Login
            </Button>
          </div>
        </form>
      </div>
      {error && (
        <p className="fixed top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/ bg-white p-4 border-l-2 border-red-600 m-5 rounded-sm">
          {error}
        </p>
      )}
    </div>
  );
};

export default Login;
