import React from "react";
import { FaArrowLeft } from "react-icons/fa";
import { useHistory } from "react-router-dom";

import Header from "../components/Header";

const ScreenLayout = () => {
  const history = useHistory();

  return (
    <div className="grid grid-cols-5 w-screen h-screen bg-red font-poppins">
      <div className="col-span-4 bg-gray-100 pt-10 px-5">
        <div className="flex justify-between">
          <button
            onClick={() => history.goBack()}
            type="button"
            className="flex-3 p-1 px-3 bg-white shadow rounded flex  items-center"
          >
            <FaArrowLeft />
            <span className="font-bold ml-2">Back</span>
          </button>
          <Header
            title="Ticketezy Main Admin Dashboard"
            className="flex-1 align-middle text-center text-3xl font-extrabold"
          />
        </div>
      </div>
      <div className="col-span-1 p-5">
        <h3 className="text-2xl font-bold text-center">Screen 1</h3>
        <h2 className="text-center text-xl font-bold mt-5">No Time To Die</h2>
        <div className="mt-5">
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">Show Time</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">11.45 AM</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">Total Seat</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">98</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">No of Ticket Sold</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">80</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">First Class Ticket Sold</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">40</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">Second Class Ticket Sold</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">40</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">1st Class Ticket Sale Amount</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">RS.6000</p>
          </div>
          <div className="flex justify-between items-center mb-7">
            <h2 className="font-bold ">2n Class Ticket Sale Amount</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">RS.4,800</p>
          </div>
          <hr className="h-1 border-none  bg-black mb-7" />
          <div className="flex justify-between mb-7">
            <h2 className="font-bold ">Total Collection</h2>
            <p className="bg-blue-500 p-1 px-4 rounded text-white">RS.10,800</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScreenLayout;
