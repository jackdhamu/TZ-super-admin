import React from "react";
import { Link, Route } from "react-router-dom";
import Header from "../components/Header";
import { GiTheater } from "react-icons/gi";

import TheaterDetails from "./TheaterDetails";
import Screens from "./Screens";
import ScreenLayout from "./ScreenLayout";

const Dashboard = () => {
  return (
    <>
      <Route path="/screen-layout" exact component={ScreenLayout} />
      <Route path="/">
        <div className="h-screen w-screen sticky left-0 top-0 bg-pink-100 grid grid-cols-5 grid-rows-1 gap-1 text-gray-500 font-poppins overflow-x-hidden">
          <div className="bg-white col-span-1 p-10">
            <Header title="Dashboard" className="text-center mb-10" />
            <Link to="/theater-details" className="flex items-center">
              <GiTheater />
              <p className="text-xl ml-4">Theater Details</p>
            </Link>
          </div>
          <div className="bg-white col-span-4">
            <Route path="/theater-details" exact component={TheaterDetails} />
            <Route path="/screens" exact component={Screens} />
          </div>
        </div>
      </Route>
    </>
  );
};

export default Dashboard;
